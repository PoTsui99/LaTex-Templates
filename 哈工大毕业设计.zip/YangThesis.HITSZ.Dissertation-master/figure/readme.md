# store figures used in thesis's context
