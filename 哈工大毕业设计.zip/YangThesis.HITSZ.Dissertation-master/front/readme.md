# store figures used in the first one and two pages
