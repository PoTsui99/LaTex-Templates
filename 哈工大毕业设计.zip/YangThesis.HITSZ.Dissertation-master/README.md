# YangThesis.HITSZ.Dissertation
## The LaTeX template for bachelor dissertation of Harbin Institute of Technology, Shenzhen (HITSZ)
