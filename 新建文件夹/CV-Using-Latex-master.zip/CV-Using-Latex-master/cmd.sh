xelatex cv.tex
xelatex coverLetter.tex
