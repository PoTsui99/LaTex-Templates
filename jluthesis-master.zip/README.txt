* 所有TeX相关文档均采用GBK编码，其余README等说明文件均采用UTF－8编码

* 

FAQs:
=====
Q: 如何从.cap 生成 .cpx ?
A:
