Q: 如何从.cap 生成 .cpx ?
 
Q: 生成2种格式的参考文献bst ?
